"""Print the data details the pipeline depends on.
python scripts/inspect_data.py /kaggle/input/competitions/gemma-4-developer-agent
"""
import glob
import json
import sys
import tarfile
from collections import Counter

import numpy as np

D = sys.argv[1]
t = json.loads(open(f"{D}/tasks.jsonl").readline())
print("task keys:", {k: type(v).__name__ for k, v in t.items()})
print("repos:", Counter(json.loads(l)["repo"] for l in open(f"{D}/tasks.jsonl")))

g = sorted(glob.glob(f"{D}/graphs/*.json"))[0]
d = json.load(open(g))
edges = d.get("links", d.get("edges", []))
print("\ngraph keys:", list(d), "| nodes:", len(d["nodes"]), "| edges:", len(edges))
print("node keys:", list(d["nodes"][0]), "| edge sample:", edges[:2])
print("edge type counts:", Counter(str(e.get("type", e.get("key", e.get("rel")))) for e in edges).most_common(8))

e = sorted(glob.glob(f"{D}/embeddings/*.npz"))[0]
z = np.load(e, allow_pickle=True)
print("\nnpz:", len(z.files), "keys; first 3:", [(k, z[k].shape, str(z[k].dtype)) for k in z.files[:3]])

s = sorted(glob.glob(f"{D}/snapshots/*"))
print("\nsnapshots:", len(s), "| suffixes:", Counter(x.rsplit(".", 1)[-1] for x in s))
with tarfile.open(s[0]) as tf:
    for i, m in enumerate(tf):
        if i >= 8:
            break
        print("  ", m.name)

for sub in ["docker", "sandbox", "wheels"]:
    print(f"\n{sub}/:", [x.rsplit("/", 1)[-1] for x in sorted(glob.glob(f"{D}/{sub}/*"))][:15])
