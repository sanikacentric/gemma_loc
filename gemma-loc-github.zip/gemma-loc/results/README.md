# gemma-loc results: code-localization trajectories for Gemma 4 E4B

Companion data for the paper "Where Small Agents Get Lost: Graph-Ranked Hints for Code Localization in Gemma 4"
(Gemma 4 Developer Agent Paper Track). Code: the `gemma-loc` Kaggle dataset / public notebook.

Two independent full runs on the 129 public development tasks of the Gemma 4 Developer Agent competition.

| Folder | Files |
|---|---|
| e4b_run1/ | base, harness, hint (Gemma 4 E4B agent) + nollm (BM25 + personalized PageRank, no LLM) |
| e4b_run2/ | base, harness, hint (independent repeat) |

Conditions: base = run_command + read_file; harness = base + official graph/embedding tools;
hint = harness + top-10 PageRank candidates in the prompt; nollm = no model.

Each line of a .jsonl file is one task:
- id, repo, cond, model
- gold: {modules, symbols, new_files}: function-level ground truth from the reference patch, as code-graph node ids
- pred: ranked predicted locations (top 5); hints: the PageRank candidates shown (hint condition only)
- metrics: mod_acc@1, mod_hit@5, sym_acc@1, sym_hit@5, sym_recall@5
- distance: call-graph hops from issue-text keyword seeds to the nearest gold symbol (99 = more than 8)
- trace: every tool call with arguments and truncated result; steps, tokens, seconds, status

Reproduce the paper's tables with the code package:  python -m src.report e4b_run1/*.jsonl

License: CC BY 4.0
