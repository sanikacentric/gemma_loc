# Where Small Agents Get Lost: Graph-Ranked Hints for Code Localization in Gemma 4

*Sanika Deshmukh R*

## Abstract

Before a coding agent can fix a bug, it has to find *where* the fix belongs. We isolate this localization step and measure it directly on the 129 development tasks of the Gemma 4 Developer Agent competition (FastAPI, Rich, Requests, HTTPX). We map each reference patch onto the competition's code graph to get function-level ground truth, then compare four localizers under an identical budget: a no-LLM baseline (BM25 + personalized PageRank over the call graph), and a Gemma 4 E4B ADK agent with (i) shell and file tools only, (ii) the official graph and embedding tools, and (iii) the official tools plus the top-10 PageRank candidates written into the prompt. Across two independent full runs, the hinted agent finds the changed function in its top 5 on **35.5%** of tasks, against **21.9%** for the plain agent (+13.7 points, exact McNemar p < 0.001) and **28.9%** with the official tools alone. The gain comes from complementarity. The graph ranking is nearly perfect when the issue text names the code (86% at 0 hops) but useless 2+ hops away (0%). The agent recovers 29 cases where the hints were wrong. Nobody solves the far cases: at 3–8 graph hops every method stays at or below 15%. A larger model (12B) under the same step budget explored more and committed less, and gained nothing from the tools. We release the code, ground-truth mapping, and full tool-call trajectories.

---

## 1. Introduction

Resolving a real issue in an unfamiliar repository is still hard for a model that fits on one accelerator. Patch success rates mix two abilities, *finding* the right code and *changing* it correctly, so when a small agent fails it is usually unclear which one broke.

The competition provides a resource aimed squarely at the first ability: a pre-built call graph and code embeddings for every repository, exposed to agents as three tools (`get_code_neighbors`, `search_similar_code`, `get_code_subgraph`). This raises three practical questions that we answer with controlled experiments:

1. **How much does each source of structure help a small agent localize?** We compare the same agent with and without the official graph tools, and against a graph algorithm with no LLM at all.
2. **When does structure help?** We stratify every result by the call-graph distance between what the issue text mentions and where the fix actually is.
3. **Can we get more out of the graph cheaply?** The agent rarely calls graph tools on its own initiative. In a pilot, a dedicated PageRank tool was called on 2 of 128 tasks. We therefore test the simplest alternative: compute the graph ranking up front and hand it to the agent as hints.

**Contributions.**

- **Measurement.** A function-level localization benchmark derived from the competition's development set, with ground truth computed by mapping reference patches onto graph nodes (§3.1). This separates localization from patch correctness.
- **Finding 1.** Graph-ranked hints are the only intervention that significantly improves the small agent, and the result replicates across two independent runs (§4.1).
- **Finding 2.** Lexical-graph ranking and agentic search are complementary. The ranking dominates near the issue text; the agent is needed elsewhere; the combination keeps most of both (§4.2).
- **Finding 3.** Fixes 3+ hops from the issue's vocabulary remain essentially unsolved by every method we tried. This is a concrete target for future work (§4.2).
- **Finding 4.** Under a fixed step budget, 12B explores longer, commits less, and gains nothing from tools (§4.4).
- **Resource.** Code, ground truth and all 774 E4B agent trajectories, each labeled with its outcome category (§6).

---

## 2. Setup

### 2.1 Data

We use the 129 public development tasks: 66 FastAPI, 48 Rich, 13 Requests and 1 HTTPX. Each has an issue description, a repository snapshot at the base commit, the reference patch, and the competition's pre-computed graph (nodes are dotted symbol paths such as `fastapi.routing.APIRouter.add_api_route`; edges are `calls`) and 256-d embeddings. One task only adds new files and has no pre-existing location to find, which leaves **128 scorable tasks**.

### 2.2 Localizers

All agents are Google ADK `LlmAgent`s on Gemma 4 served by vLLM, with temperature 0 and at most 15 LLM calls per task. The tool implementations mirror the competition harness: same names, same arguments, and the same 5,000-character and 150-line output limits. The agent must answer with `submit_locations`, a ranked list of up to 5 dotted symbols. If it runs out of budget, it gets one final turn in which `submit_locations` is its only tool. This mirrors the harness's continuation nudges and is applied identically to every condition.

| Condition | What the localizer has |
|---|---|
| **No-LLM** | No model. BM25 over node names and code from the issue text gives 5 seed nodes; personalized PageRank (α = 0.85) on the undirected call graph ranks the rest; tests are excluded. |
| **Agent (base)** | `run_command`, `read_file` |
| **Agent + official tools** | base + `search_similar_code`, `get_code_neighbors`, `get_code_subgraph` (the competition default) |
| **Agent + hints (ours)** | official tools, plus the No-LLM top-10 list appended to the issue as *"candidate locations ranked by a code-graph analysis (helpful but may be wrong; verify by reading the code)"* |

The hint condition costs one PageRank computation per task, under a second on CPU. It adds no tool calls and no training.

### 2.3 Metrics and statistics

The main metric is **sym_hit@5**: whether any of the top-5 predictions is a changed symbol or lies inside one. We also report module-level hits and top-1 accuracy. All conditions are scored against the same gold set, and the report checks that gold is identical across runs. For confidence intervals we use 2,000-sample bootstrap 95% CIs. Paired comparisons use the **exact McNemar test** on discordant tasks with **Holm correction** across comparisons, plus paired-difference bootstrap CIs. As a sensitivity check we re-score the 97 tasks whose gold is at function or class level, which excludes edits only to module-level code.

---

## 3. Method details

### 3.1 Ground truth from patches

For each modified file in the reference patch (test files and runner configs excluded, as in the official scorer), we parse the pre-fix source with `ast`. Each changed region is mapped to its innermost enclosing function or class:

- **Removed or modified lines** map to the symbol containing them.
- **Pure insertions** are the subtle case. A new method added between two methods sits *after* the last line of the previous method, so naive anchoring credits the wrong neighbor. We anchor an insertion to the line before it and the line after it. We credit the symbol before the insertion only if the inserted code is indented deeper than that symbol's definition; otherwise we credit their common parent (class or module).

Symbols are matched to the graph's naming (which drops prefixes such as FastAPI's `docs_src.`), and agent answers get the same mapping. Twelve regression cases cover insertion edge cases.

### 3.2 Graph distance

For each task we take the five BM25 seed nodes from the issue text and compute the shortest undirected call-graph path to the nearest gold symbol, capped at 8 hops. Distance 0 means the issue's vocabulary already points at the fix. Larger distances mean the agent must reason from the mentioned code to code it calls or that calls it.

| Distance | 0 | 1 | 2 | 3–8 | unreachable (> 8) | gold not in graph |
|---|---|---|---|---|---|---|
| Tasks | 29 | 14 | 22 | 44 | 7 | 12 |

Just over a third of tasks (44 of 128) need 3 or more hops. That is the main reason pure retrieval is not enough.

### 3.3 Integrity safeguards

Each of these is covered by tests:

- **Isolated workspaces** per parallel run (an early shared directory corrupted gold).
- **No crash-to-zero:** tools return error JSON instead of aborting the episode, as the official harness does.
- **Snapshot hygiene:** dotfiles intact, `.git` removed so no later history is readable.
- **Leakage audit.** The agent's shell is restricted to its repository copy, and the report audits every tool output for markers of task or gold data. **Zero leak suspects and zero blocked commands** were recorded in every run reported here.

---

## 4. Results

### 4.1 Graph-ranked hints are the only significant improvement

![Figure 1](figures/figure1_main_result.png)

**Table 1.** Gemma 4 E4B, 128 tasks. sym_hit@5 (%) with 95% bootstrap CI. Run 1 and Run 2 are independent full runs of the same code.

| Localizer | Run 1 | Run 2 | Pooled (256) | vs. base: Δ, wins/losses | p (exact McNemar) |
|---|---|---|---|---|---|
| No-LLM BM25 + PageRank | 25.8 | 25.8 | 25.8 [19.0, 34.0] | — | — |
| Agent (base) | 19.5 | 24.2 | 21.9 [17.2, 27.0] | — | — |
| Agent + official tools | 28.9 | 28.9 | 28.9 [23.4, 34.4] | +7.0 [+1.6, +12.5], 37/19 | 0.022 |
| **Agent + hints (ours)** | **34.4** | **36.7** | **35.5 [29.7, 41.0]** | **+13.7 [+7.4, +19.5], 52/17** | **< 0.001** |

Holm-corrected within each run (3 comparisons against base), the hint condition is significant in both runs (p = 0.004 and p = 0.034). The official tools are not significant in either run on its own (p = 0.058 and p = 0.72); the pooled harness-vs-base difference shown above is significant only before multiple-comparison correction. Hints versus official tools is +6.6 points pooled (43 wins, 26 losses, p = 0.053). It is suggestive, but we do not claim it as significant. On the stricter function/class-level subset (n = 97), the ordering holds: hints 34.0%, official tools 24.7%, base 14.4% (Run 1).

Two temperature-0 runs agree on 86–90% of tasks (serving nondeterminism); base-agent variation between runs (19.5% vs 24.2%) is as large as some published effects, which is why we report both runs and paired tests.

### 4.2 Retrieval and agents are complementary, and far fixes are unsolved

![Figure 2](figures/figure2_by_distance.png)

**Table 2.** sym_hit@5 (%) by call-graph distance from issue keywords to gold. Agents pooled over 2 runs.

| Localizer | 0 hops (29) | 1 hop (14) | 2 hops (22) | 3–8 hops (44) |
|---|---|---|---|---|
| No-LLM BM25 + PageRank | **86** | **43** | 0 | 0 |
| Agent (base) | 22 | 4 | 27 | 14 |
| Agent + official tools | 48 | 21 | **32** | **15** |
| Agent + hints (ours) | 71 | **43** | **32** | 7 |

The two families fail in opposite places. The graph ranking almost always succeeds when the issue names the right code, and it never succeeds two or more hops away. The agent is poor at the easy cases: without tools it finds the named function only 22% of the time, because it wanders to related files. It is the only thing that works further out. Hints recover most of the ranking's strength at distance 0–1 while keeping the agent's performance at distance 2.

Inside the hint condition (256 task-runs), the hint list contained a gold symbol in 92 cases. The agent kept it in 62 and dropped it in 30. In another 29 cases the hints were wrong and the agent found the fix anyway. The agent took its top answer from the hint list 64% of the time, so it uses the hints but does not copy them blindly.

At **3–8 hops every method stays at or below 15%**, and hints slightly hurt (7%). A plausible reason is that confident but wrong candidates anchor the agent near the issue's vocabulary, when the fix lives deeper in the call chain. We see this distance band as the main open problem for small-model localization.

### 4.3 How the agents fail

**Table 3.** Outcome categories (% of 256 task-runs per condition).

| Localizer | Found | Right file, wrong symbol | Wrong file |
|---|---|---|---|
| Agent (base) | 21.9 | 35.9 | 42.2 |
| Agent + official tools | 28.9 | 27.0 | 44.1 |
| Agent + hints | 35.5 | 23.8 | 40.6 |

Most of the improvement comes from converting *right file, wrong symbol* into *found*. Wrong-file errors barely move: about 40% of attempts never reach the right file. Tool usage is lopsided. Even with graph tools available, `read_file` and `run_command` make up most calls (e.g., 914 and 645 of 2,057 calls in the hint condition). `get_code_neighbors` was called only 46–67 times across 256 task-runs, and `get_code_subgraph` 1–3 times. Left to itself, the small model barely uses the graph. Pushing the graph's output into the prompt is what makes the structure count.

### 4.4 A larger model under the same budget (12B)

We ran the same three agent conditions with Gemma 4 12B under the same 15-call budget. This run used an earlier version of the final-answer step, so we report it as a supplementary result.

| 12B | sym_hit@5 | Budget exhausted | Answered via `submit_locations` |
|---|---|---|---|
| Agent (base) | 19.5% | 91 / 129 | 59 |
| Agent + official tools | 17.2% | 100 / 129 | 44 |
| Agent + hints | 16.4% | 104 / 129 | 33 |

12B exhausted the budget on 70–80% of tasks and often gave no final answer even when offered only the submit tool; no condition difference was significant (Holm p = 1.0). Under a tight budget, the larger model did not stop to commit. Fair cross-size comparison needs per-model budgets and answer prompts, which we leave to future work.

---

## 5. Related work

**Benchmarks and agents.** SWE-bench (Jimenez et al., 2024) established test-scored issue resolution. SWE-agent (Yang et al., 2024) showed that interface design strongly affects success. AutoCodeRover (Zhang et al., 2024) localizes with AST-level search before patching. Agentless (Xia et al., 2025) showed a fixed localize-repair-validate pipeline is competitive; our hint condition adapts that idea to an agent: a cheap fixed localizer first, agent verification second.

**Graphs for code localization.** RepoGraph (Ouyang et al., 2025) builds repository-level code graphs to give agents structural context. LocAgent (Chen et al., 2025) parses code into a heterogeneous graph and lets an LLM agent traverse it for localization, reporting strong results with fine-tuned models. Both expose the graph as tools or context. Our evidence suggests that for small models, *tool availability is not tool use*: the agent rarely traverses on its own, and pre-computed rankings in the prompt help more.

**Ranking and statistics.** BM25 (Robertson & Zaragoza, 2009) and personalized PageRank (Haveliwala, 2002) are deliberately simple, so gains reflect how the ranking is delivered. Paired tests follow McNemar (1947) with Holm (1979) correction.

---

## 6. Released resources

- **Code** (Apache-2.0): data loaders for the competition formats, patch-to-graph ground truth, harness-identical tools, the ADK agent, and the reporting/statistics script. It ships with 32 tests, including tests built in the exact competition file formats and an end-to-end test through an OpenAI-compatible server.
- **Ground truth:** per task, the gold modules and symbols, the new files, and the graph distance.
- **Trajectories:** every tool call and truncated result for all agent runs (774 E4B task-runs: 2 runs × 3 conditions × 129 tasks), with outcome labels (found / right file, wrong symbol / wrong file), token counts and run status. These are useful for studying how small agents explore, and for building fine-tuning data that targets the failure modes in Table 3.

**Public notebook:** https://www.kaggle.com/code/sanikadeshmukhr/getting-started-gemma-4-developer-agent

**Code dataset:** https://www.kaggle.com/datasets/sanikadeshmukhr/gemma-loc

**Results & trajectories dataset:** https://www.kaggle.com/datasets/sanikadeshmukhr/gemma-loc-results

---

## 7. Limitations

- **Scope.** We measure localization, not end-to-end patch correctness. A correct location is necessary but not sufficient for a passing patch.
- **Data size.** 128 tasks from four repositories. FastAPI and Rich dominate, and HTTPX has a single task.
- **Run count.** Two runs for E4B and one for 12B. The 12B run used an earlier version of the final-answer step.
- **Ground-truth leniency.** About a quarter of tasks have module-level gold, which makes a module-level prediction count as correct. The function/class-level subset (§4.1) shows the same ordering.
- **Shell restriction** is a pattern guard, not a container; the audit found no access to task or gold data.

## 8. Conclusion

For a small local model, the cheapest way to get value from a code graph is not to hand it graph tools but to hand it the graph's answer. Pre-computed PageRank hints raised function-level localization from 21.9% to 35.5% across two independent runs, at negligible cost. The analysis also shows where the problem remains: when the fix lives three or more calls away from anything the issue mentions, neither retrieval nor the agent finds it. Closing that gap, perhaps by guiding traversal along the call chain rather than ranking around the issue text, is the natural next step.

---

## References

- Chen, Z. et al. (2025). *LocAgent: Graph-Guided LLM Agents for Code Localization.* ACL 2025.
- Haveliwala, T. (2002). *Topic-Sensitive PageRank.* WWW 2002.
- Holm, S. (1979). *A Simple Sequentially Rejective Multiple Test Procedure.* Scandinavian Journal of Statistics.
- Jimenez, C. E. et al. (2024). *SWE-bench: Can Language Models Resolve Real-World GitHub Issues?* ICLR 2024.
- McNemar, Q. (1947). *Note on the sampling error of the difference between correlated proportions or percentages.* Psychometrika.
- Ouyang, S. et al. (2025). *RepoGraph: Enhancing AI Software Engineering with Repository-level Code Graph.* ICLR 2025.
- Robertson, S. & Zaragoza, H. (2009). *The Probabilistic Relevance Framework: BM25 and Beyond.* Foundations and Trends in IR.
- Xia, C. S. et al. (2025). *Agentless: Demystifying LLM-based Software Engineering Agents.* FSE 2025.
- Yang, J. et al. (2024). *SWE-agent: Agent-Computer Interfaces Enable Automated Software Engineering.* NeurIPS 2024.
- Zhang, Y. et al. (2024). *AutoCodeRover: Autonomous Program Improvement.* ISSTA 2024.
- Google (2026). *Gemma 4 Developer Agent Competition: harness documentation (HARNESS_README).* Kaggle.
