# Where Small Agents Get Lost
### Graph-ranked hints for code localization with Gemma 4

Research code, results and paper for the **Google DeepMind Gemma 4 Developer Agent – Paper Track** (Kaggle, 2026).

> Before an AI agent can fix a bug, it has to **find where the fix belongs**. This project measures that step directly
> and shows a zero-cost way to make a small local model much better at it.

![Main result](paper/figures/figure1_main_result.png)

## Key results (Gemma 4 E4B, 128 tasks, 2 independent runs)

| Localizer | Correct function in top 5 |
|---|---|
| No-LLM: BM25 + personalized PageRank | 25.8% |
| Agent, basic tools | 21.9% |
| Agent + official code-graph tools | 28.9% |
| **Agent + graph-ranked hints (ours)** | **35.5%** (+13.7 pts, exact McNemar p < 0.001) |

- **Tool availability ≠ tool use.** The small model rarely calls graph tools on its own; handing it the graph's ranking works better.
- **Retrieval and agents are complementary.** Graph ranking: 86% when the issue names the code, 0% two or more hops away. The agent covers the rest.
- **Far fixes are unsolved.** When the fix is 3+ call-graph hops from the issue text, every method stays at or below 15%.
- **Bigger isn't automatically better.** Under the same step budget, Gemma 4 12B explored more but rarely committed to an answer.

📄 **Paper:** [paper/PAPER.md](paper/PAPER.md)  
🏆 **Kaggle writeup:** https://www.kaggle.com/competitions/gemma-4-developer-agent-paper/writeups/where-small-agents-get-lost-graph-ranked-hints-fo  
💻 **Kaggle notebook:** https://www.kaggle.com/code/sanikadeshmukhr/getting-started-gemma-4-developer-agent  
📦 **Results dataset:** https://www.kaggle.com/datasets/sanikadeshmukhr/gemma-loc-results

## How it works

```
issue text ──► BM25 seeds ──► personalized PageRank on call graph ──► top-10 candidate functions
                                                                            │  (written into the prompt)
                                                                            ▼
             Gemma 4 agent (Google ADK + vLLM) ── read_file / run_command / graph tools ──► submit_locations
                                                                            │
reference patch ──► AST mapping ──► gold functions ──────────────────────► score (hit@5, McNemar, CIs)
```

| Folder | What's inside |
|---|---|
| `src/data.py` | Loads competition tasks, code graphs, embeddings and repo snapshots |
| `src/ground_truth.py` | Maps a reference patch to the exact functions it changes (handles insertions, decorators, EOF) |
| `src/graph_tools.py` | Harness-identical agent tools, BM25 + PageRank ranker, sandbox guard |
| `src/agent.py` | Google ADK localization agent with a forced final-answer step |
| `src/run_localize.py` | Runs one condition over all tasks (resumable, parallel-safe) |
| `src/metrics.py`, `src/report.py` | Metrics, bootstrap CIs, exact McNemar + Holm, distance & leakage analysis |
| `tests/` | 32 tests, including real-format data and an end-to-end test through an OpenAI-compatible server |
| `results/` | Full per-task results and tool-call trajectories for both E4B runs |
| `paper/` | The paper and figures |

## Conditions

| Condition | Tools |
|---|---|
| `nollm` | No model: BM25 + personalized PageRank |
| `base` | `run_command`, `read_file` |
| `harness` | base + `search_similar_code`, `get_code_neighbors`, `get_code_subgraph` (competition default) |
| `hint` | harness + top-10 PageRank candidates in the prompt |
| `full` | harness + a `rank_related` PageRank tool (pilot only) |

## Quick start

```bash
pip install -r requirements.txt
python -m pytest -q tests/                                  # 32 tests, ~15 s, no GPU

# Reproduce the paper's tables from the released results
python -m src.report results/e4b_run1/base_e4b.jsonl results/e4b_run1/harness_e4b.jsonl \
                     results/e4b_run1/hint_e4b.jsonl  results/e4b_run1/nollm_e4b.jsonl
```

### Run the experiments (Kaggle, GPU L4×4, internet off)
1. Attach the competition data, the Gemma 4 models and the official wheelhouse to a notebook.
2. Start Gemma with vLLM (`--tool-call-parser gemma4 --reasoning-parser gemma4`) and set
   `OPENAI_API_BASE`, `MODEL`, `MODEL_LABEL`.
3. Run each condition:
```bash
DATA=/kaggle/input/competitions/gemma-4-developer-agent
for c in base harness hint nollm; do
  python -m src.run_localize --data $DATA --cond $c --out results/${c}_e4b.jsonl &
done; wait
python -m src.report results/*_e4b.jsonl
```
A full run takes about 1 hour on L4×4 with E4B.

## Citation
```
Sanika Deshmukh R. Where Small Agents Get Lost: Graph-Ranked Hints for Code Localization in Gemma 4.
Gemma 4 Developer Agent Paper Track, Kaggle, 2026.
```

## License
Code: Apache-2.0. Results and paper: CC BY 4.0.
