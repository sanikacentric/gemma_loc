"""End-to-end test on a synthetic dataset laid out exactly like the competition data
(tasks.jsonl, graphs/<repo>_<commit>.json node-link, embeddings/<repo>_<commit>.npz, snapshots/<id>.tgz).
Run: python -m pytest -q tests/"""
import asyncio
import io
import json
import subprocess
import sys
import tarfile
from pathlib import Path

import numpy as np
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.genai import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.agent import localize  # noqa: E402
from src.data import extract_snapshot, find_file, load_embeddings, load_graph, load_tasks  # noqa: E402
from src.ground_truth import gold_locations  # noqa: E402
from src.graph_tools import CodeGraph, nollm_localize  # noqa: E402
from src.metrics import score  # noqa: E402

FILES = {
    "README.md": "demo",
    "pkg/__init__.py": "",
    "pkg/client.py": '''"""HTTP client."""
from .headers import normalize_header


class Client:
    def send(self, request):
        """Send a request after normalising headers."""
        request.headers = {normalize_header(k): v for k, v in request.headers.items()}
        return self._transport(request)

    def _transport(self, request):
        return request
''',
    "pkg/headers.py": '''def normalize_header(name):
    """Normalise an HTTP header name."""
    return name.title()


def unrelated_helper():
    return 1
''',
}
PATCH = '''--- a/pkg/headers.py
+++ b/pkg/headers.py
@@ -1,3 +1,3 @@
 def normalize_header(name):
     """Normalise an HTTP header name."""
-    return name.title()
+    return name.strip().title()
--- /dev/null
+++ b/pkg/new_module.py
@@ -0,0 +1,2 @@
+def added():
+    return 1
--- a/tests/test_headers.py
+++ b/tests/test_headers.py
@@ -0,0 +1,2 @@
+def test_strip():
+    assert True
'''
ISSUE = "Header names with surrounding whitespace are not normalised: normalize_header should strip spaces."
NODES = {
    "pkg.client.Client": "class Client: ...",
    "pkg.client.Client.send": FILES["pkg/client.py"].split("def send")[1][:200],
    "pkg.client.Client._transport": "def _transport(self, request): return request",
    "pkg.headers.normalize_header": "def normalize_header(name): return name.title()",
    "pkg.headers.unrelated_helper": "def unrelated_helper(): return 1",
}
EDGES = [("pkg.client.Client.send", "pkg.headers.normalize_header", "calls"),
         ("pkg.client.Client.send", "pkg.client.Client._transport", "calls"),
         ("pkg.client.Client", "pkg.client.Client.send", "contains")]


def make_dataset(d):
    (d / "snapshots").mkdir(parents=True)
    with tarfile.open(d / "snapshots" / "demo_1.tgz", "w:gz") as tf:  # repo wrapped in one top folder
        for rel, text in FILES.items():
            data = text.encode()
            info = tarfile.TarInfo(f"repo/{rel}")
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
    (d / "tasks.jsonl").write_text(json.dumps({
        "instance_id": "demo_1", "repo": "demo/pkg", "base_commit": "abc123",
        "problem_statement": ISSUE, "patch": PATCH, "test_patch": "", "hints_text": ""}) + "\n")
    (d / "graphs").mkdir()
    (d / "graphs" / "pkg_abc123.json").write_text(json.dumps({
        "directed": True, "multigraph": True, "graph": {},
        "nodes": [{"name": k, "text": v, "id": k} for k, v in NODES.items()],
        "links": [{"source": a, "target": b, "type": t, "key": 0} for a, b, t in EDGES]}))
    (d / "embeddings").mkdir()
    np.savez(d / "embeddings" / "pkg_abc123.npz", names=np.array(list(NODES)),
             embeddings=np.random.default_rng(0).random((len(NODES), 256)))
    return d


def setup(tmp_path):
    d = make_dataset(tmp_path / "data")
    t = load_tasks(d)[0]
    ws = extract_snapshot(d / "snapshots" / "demo_1.tgz", tmp_path / "ws")
    G = load_graph(find_file(d, "graphs", t, ".json"))
    cg = CodeGraph(G, *load_embeddings(find_file(d, "embeddings", t, ".npz")))
    read = lambda p: (ws / p).read_text() if (ws / p).is_file() else None
    return d, t, ws, cg, gold_locations(t["patch"], read, cg.idset)


def test_snapshot_strips_top_folder(tmp_path):
    _, _, ws, _, _ = setup(tmp_path)
    assert (ws / "pkg" / "headers.py").is_file()


def test_partial_extract(tmp_path):
    d = make_dataset(tmp_path / "data")
    ws = extract_snapshot(d / "snapshots" / "demo_1.tgz", tmp_path / "p", only={"pkg/headers.py"})
    assert [p.name for p in ws.rglob("*.py")] == ["headers.py"]


def test_ground_truth(tmp_path):
    *_, gold = setup(tmp_path)
    assert gold == {"modules": {"pkg.headers"}, "symbols": {"pkg.headers.normalize_header"},
                    "new_files": {"pkg/new_module.py"}}


def test_embeddings_aligned(tmp_path):
    _, _, _, cg, _ = setup(tmp_path)
    assert len(cg.row) == len(NODES)


def test_tools(tmp_path):
    _, _, ws, cg, _ = setup(tmp_path)
    tl = {f.__name__: f for f in cg.tools("full", ws)}
    assert "Client.send" in tl["get_code_neighbors"]("normalize_header")
    assert '"from": "pkg.client.Client.send"' in tl["get_code_subgraph"]("Client.send, normalize_header")
    assert "similarity" in tl["search_similar_code"]("Client.send")
    assert "normalize_header" in tl["search_similar_code"]("strip header whitespace")  # keyword fallback
    assert "name.title()" in tl["read_file"]("pkg/headers.py")
    assert "headers.py" in tl["run_command"]("grep -rn 'def normalize_header' .")
    assert "ranked" in tl["rank_related"]("pkg.client.Client.send")
    assert [f.__name__ for f in cg.tools("base", ws)] == ["run_command", "read_file"]


def test_nollm_finds_gold(tmp_path):
    _, t, _, cg, gold = setup(tmp_path)
    m = score(nollm_localize(cg, t["issue"]), gold)
    assert m["sym_acc@1"] == 1.0 and m["mod_acc@1"] == 1.0


class ScriptedLlm(BaseLlm):
    """Fake model: neighbours -> read -> submit. Exercises the real ADK tool loop."""
    step: int = 0

    async def generate_content_async(self, llm_request, stream=False):
        script = [("get_code_neighbors", {"node": "Client.send"}),
                  ("read_file", {"filepath": "pkg/headers.py", "start_line": 1, "end_line": 3}),
                  ("submit_locations", {"locations": "pkg.headers.normalize_header, pkg/client.py::Client.send"})]
        name, args = script[min(self.step, 2)]
        self.step += 1
        yield LlmResponse(content=types.Content(role="model", parts=[
            types.Part(function_call=types.FunctionCall(name=name, args=args))]))


def test_adk_agent_loop(tmp_path):
    _, t, ws, cg, gold = setup(tmp_path)
    res = asyncio.run(localize(cg, t["issue"], "graph", ws, model=ScriptedLlm(model="fake")))
    assert res["status"] == "ok", res["status"]
    assert res["pred"] == ["pkg.headers.normalize_header", "pkg.client.Client.send"]
    assert res["steps"] == 3 and score(res["pred"], gold)["sym_acc@1"] == 1.0


def test_cli_and_report(tmp_path):
    d = make_dataset(tmp_path / "data")
    out = tmp_path / "res" / "nollm.jsonl"
    for _ in range(2):  # second run must resume, not duplicate
        subprocess.run([sys.executable, "-m", "src.run_localize", "--data", str(d), "--cond", "nollm",
                        "--out", str(out), "--tmp", str(tmp_path / "ws")], cwd=ROOT, check=True)
    assert len(out.read_text().splitlines()) == 1
    r = subprocess.run([sys.executable, "-m", "src.report", str(out)], cwd=ROOT, check=True,
                       capture_output=True, text=True)
    assert "nollm" in r.stdout and "1 scorable" in r.stdout


def test_inspect_script(tmp_path):
    d = make_dataset(tmp_path / "data")
    r = subprocess.run([sys.executable, "scripts/inspect_data.py", str(d)], cwd=ROOT, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_gold_drops_redundant_module_and_tests_filtered():
    from src.ground_truth import is_test_symbol
    assert is_test_symbol("tests.test_x.test_y") and is_test_symbol("pkg.test_utils.f") and not is_test_symbol("pkg.attest.f")
    patch = """--- a/pkg/headers.py
+++ b/pkg/headers.py
@@ -1,3 +1,4 @@
+import os
 def normalize_header(name):
     \\"\\"\\"Normalise an HTTP header name.\\"\\"\\"
-    return name.title()
+    return name.strip().title()
"""
    gold = gold_locations(patch, lambda p: FILES.get(p), set(NODES))
    assert gold["symbols"] == {"pkg.headers.normalize_header"}


def test_normalize_model_answer_formats():
    from src.agent import _norm
    from src.ground_truth import resolve
    assert _norm("fastapi/sse.py:_check_id_no_null") == "fastapi.sse._check_id_no_null"
    assert _norm("fastapi/params.py:Header.__init__") == "fastapi.params.Header.__init__"
    assert _norm("pkg/client.py::Client.send") == "pkg.client.Client.send"
    assert _norm("`pkg/headers.py`") == "pkg.headers"
    assert _norm("pkg/headers.py:12-20") == "pkg.headers"
    assert _norm("/workspace/pkg/__init__.py") == "pkg"
    assert _norm("pkg.client.Client.send") == "pkg.client.Client.send"
    assert _norm("scripts/add_latest_release_date.py") == "scripts.add_latest_release_date"
    # unknown nested symbol climbs to its graph parent
    assert resolve("pkg.client.Client.send.inner", set(NODES)) == "pkg.client.Client.send"


class ForgetfulLlm(BaseLlm):
    """Answers in plain text first (no submit), then submits after the nudge."""
    step: int = 0

    async def generate_content_async(self, llm_request, stream=False):
        self.step += 1
        if self.step == 1:
            yield LlmResponse(content=types.Content(role="model", parts=[types.Part(text="I think it is in headers.")]))
        else:
            yield LlmResponse(content=types.Content(role="model", parts=[types.Part(function_call=types.FunctionCall(
                name="submit_locations", args={"locations": "pkg/headers.py:normalize_header"}))]))


def test_nudge_recovers_missing_submit(tmp_path):
    _, t, ws, cg, gold = setup(tmp_path)
    res = asyncio.run(localize(cg, t["issue"], "base", ws, model=ForgetfulLlm(model="fake")))
    assert res["pred"] == ["pkg.headers.normalize_header"] and res["status"] == "ok"
    assert any(t.get("nudged") for t in res["trace"])


class EchoHintLlm(BaseLlm):
    """Submits the first hint it finds in the prompt: proves hints reach the model."""
    async def generate_content_async(self, llm_request, stream=False):
        prompt = " ".join(p.text or "" for c in llm_request.contents for p in (c.parts or []))
        first = prompt.split("1. ")[1].split()[0] if "1. " in prompt else "none"
        yield LlmResponse(content=types.Content(role="model", parts=[types.Part(function_call=types.FunctionCall(
            name="submit_locations", args={"locations": first}))]))


def test_hint_condition(tmp_path):
    _, t, ws, cg, gold = setup(tmp_path)
    hints = nollm_localize(cg, t["issue"])
    res = asyncio.run(localize(cg, t["issue"], "hint", ws, model=EchoHintLlm(model="fake"), hints=hints))
    assert res["pred"] == [hints[0]] and score(res["pred"], gold)["sym_acc@1"] == 1.0
    assert "rank_related" not in [f.__name__ for f in cg.tools("hint", ws)]
