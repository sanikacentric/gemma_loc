"""Tests on a dataset built in the EXACT real Kaggle formats, plus one test per issue found in review:
- graphs use the "edges" key; docs_src files appear in the graph WITHOUT the docs_src prefix; only 'calls' edges
- embeddings: one npz key per node id
- snapshots: tar entries './', './.git/...', './.github/...', './pkg/...'
"""
import asyncio
import io
import json
import subprocess
import sys
import tarfile
from pathlib import Path

import numpy as np
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.genai import types

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.agent import _norm, localize  # noqa: E402
from src.data import extract_snapshot, find_file, load_embeddings, load_graph, load_tasks  # noqa: E402
from src.ground_truth import gold_locations  # noqa: E402
from src.graph_tools import CodeGraph, nollm_localize  # noqa: E402
from src.metrics import holm, mcnemar_exact, score  # noqa: E402
from src.run_localize import _to_graph  # noqa: E402

ROUTING = '''class APIRouter:
    def get(self, path):
        return self.add_api_route(path)

    def add_api_route(self, path):
        return path


def helper():
    return 1
'''
DOCS = '''def get_settings():
    return {"a": 1}
'''
FILES = {
    "README.md": "x", ".github/workflows/ci.yml": "on: push", ".flake8": "[flake8]",
    ".git/HEAD": "ref: refs/heads/main", ".git/config": "[core]",
    "fastapi/__init__.py": "", "fastapi/routing.py": ROUTING,
    "docs_src/settings/app01/main.py": DOCS,
    "tests/test_routing.py": "def test_get():\n    assert True\n",
}
NODES = ["fastapi.routing.APIRouter", "fastapi.routing.APIRouter.get", "fastapi.routing.APIRouter.add_api_route",
         "fastapi.routing.helper", "settings.app01.main.get_settings", "tests.test_routing.test_get"]
EDGES = [("fastapi.routing.APIRouter.get", "fastapi.routing.APIRouter.add_api_route"),
         ("tests.test_routing.test_get", "fastapi.routing.APIRouter.get")]
# Patch 1: add a NEW method between get and add_api_route (git-style insertion after a blank line)
PATCH_INSERT = '''--- a/fastapi/routing.py
+++ b/fastapi/routing.py
@@ -3,3 +3,6 @@
         return self.add_api_route(path)

+    def post(self, path):
+        return self.add_api_route(path)
+
     def add_api_route(self, path):
'''
# Patch 2: change a docs_src file (graph drops the docs_src prefix)
PATCH_DOCS = '''--- a/docs_src/settings/app01/main.py
+++ b/docs_src/settings/app01/main.py
@@ -1,2 +1,2 @@
 def get_settings():
-    return {"a": 1}
+    return {"a": 2}
'''


def make_real(tmp):
    d = tmp / "data"
    (d / "snapshots").mkdir(parents=True)
    for tid in ("fastapi_1", "fastapi_2"):
        with tarfile.open(d / "snapshots" / f"{tid}.tgz", "w:gz") as tf:
            info = tarfile.TarInfo(".")
            info.type = tarfile.DIRTYPE
            tf.addfile(info)
            for rel, text in FILES.items():
                data = text.encode()
                info = tarfile.TarInfo(f"./{rel}")
                info.size = len(data)
                tf.addfile(info, io.BytesIO(data))
    rows = [{"instance_id": "fastapi_1", "repo": "fastapi/fastapi", "base_commit": "c1",
             "problem_statement": "APIRouter needs a post method like get that calls add_api_route",
             "patch": PATCH_INSERT, "test_patch": "", "hints_text": "", "created_at": ""},
            {"instance_id": "fastapi_2", "repo": "fastapi/fastapi", "base_commit": "c1",
             "problem_statement": "settings example get_settings returns wrong value",
             "patch": PATCH_DOCS, "test_patch": "", "hints_text": "", "created_at": ""}]
    (d / "tasks.jsonl").write_text("\n".join(json.dumps(r) for r in rows) + "\n")
    (d / "graphs").mkdir()
    (d / "graphs" / "fastapi_c1.json").write_text(json.dumps({
        "directed": True, "multigraph": True, "graph": {"repo_name": "fastapi_c1"},
        "nodes": [{"name": n, "text": n.split(".")[-1], "id": n} for n in NODES],
        "edges": [{"type": "calls", "source": a, "target": b, "key": 0} for a, b in EDGES]}))
    (d / "embeddings").mkdir()
    rng = np.random.default_rng(0)
    np.savez(d / "embeddings" / "fastapi_c1.npz", **{n: rng.random(256).astype(np.float32) for n in NODES})
    return d


def load_task(tmp, i):
    d = make_real(tmp)
    t = load_tasks(d)[i]
    ws = extract_snapshot(d / "snapshots" / f"{t['id']}.tgz", tmp / f"ws{i}")
    cg = CodeGraph(load_graph(find_file(d, "graphs", t, ".json")),
                   *load_embeddings(find_file(d, "embeddings", t, ".npz")))
    gold = gold_locations(t["patch"], lambda p: (ws / p).read_text() if (ws / p).is_file() else None, cg.idset)
    return d, t, ws, cg, gold


def test_real_graph_and_embeddings_load(tmp_path):
    _, _, _, cg, _ = load_task(tmp_path, 0)
    assert cg.G.number_of_edges() == 2 and len(cg.row) == len(NODES)


def test_snapshot_keeps_dotfiles_and_drops_git(tmp_path):
    _, _, ws, _, _ = load_task(tmp_path, 0)
    assert (ws / ".github" / "workflows" / "ci.yml").is_file() and (ws / ".flake8").is_file()
    assert not (ws / "github").exists() and not (ws / "git").exists() and not (ws / ".git").exists()
    assert (ws / "fastapi" / "routing.py").is_file()


def test_insertion_credits_enclosing_class_not_neighbour(tmp_path):
    *_, gold = load_task(tmp_path, 0)
    assert gold["symbols"] == {"fastapi.routing.APIRouter"}


def test_docs_src_gold_and_prediction_use_graph_naming(tmp_path):
    _, _, _, cg, gold = load_task(tmp_path, 1)
    assert gold["symbols"] == {"settings.app01.main.get_settings"} and gold["modules"] == {"settings.app01.main"}
    pred = _to_graph(_norm("docs_src/settings/app01/main.py"), cg.idset)       # agent names the file
    assert score([pred], gold)["mod_hit@5"] == 1.0
    pred = _to_graph(_norm("docs_src/settings/app01/main.py:get_settings"), cg.idset)
    assert score([pred], gold)["sym_hit@5"] == 1.0


def test_norm_keeps_dotted_names_containing_py():
    assert _norm("_pytest.python.Function.setup") == "_pytest.python.Function.setup"
    assert _norm("pkg.pyutils.f") == "pkg.pyutils.f"
    assert _norm("docs_src/python_types/tutorial001.py") == "docs_src.python_types.tutorial001"
    assert _norm("./fastapi/routing.py:APIRouter.get") == "fastapi.routing.APIRouter.get"


def test_tools_never_raise(tmp_path):
    _, _, ws, cg, _ = load_task(tmp_path, 0)
    tl = {f.__name__: f for f in cg.tools("full", ws)}
    assert '"status": "ok"' in tl["get_code_neighbors"]("APIRouter.get", max_neighbors="all")
    assert '"status": "ok"' in tl["read_file"]("fastapi/routing.py", end_line="end")
    assert '"status": "ok"' in tl["read_file"](str(ws / "fastapi/routing.py"))          # absolute path after pwd
    assert '"status": "ok"' in tl["search_similar_code"]("APIRouter.get", k="many")
    assert "error" in tl["rank_related"]("") or '"ranked": []' in tl["rank_related"]("")


def test_run_command_stays_inside_workspace(tmp_path):
    _, _, ws, cg, _ = load_task(tmp_path, 0)
    run = {f.__name__: f for f in cg.tools("base", ws)}["run_command"]
    for bad in ["cat /kaggle/input/x/tasks.jsonl", "ls ..", "cat ../x", "cd / && ls", "ls ~", "cat $HOME/x",
                "find / -name '*.jsonl'", "grep -r gold /tmp"]:
        assert "NotAllowed" in run(bad), bad
    assert "routing.py" in run("grep -rln 'add_api_route' . 2>/dev/null")
    assert "routing.py" in run("ls /workspace/fastapi")      # harness-style path is mapped to the repo root


def test_test_symbols_never_predicted(tmp_path):
    _, t, _, cg, _ = load_task(tmp_path, 0)
    assert not any(p.startswith("tests.") for p in nollm_localize(cg, t["issue"] + " test_get"))


class RaisingLlm(BaseLlm):
    """First a tool call with a bad argument type (would have crashed before), then a proper submit."""
    step: int = 0

    async def generate_content_async(self, llm_request, stream=False):
        self.step += 1
        call = (("get_code_neighbors", {"node": "APIRouter.get", "max_neighbors": "all"}) if self.step == 1 else
                ("submit_locations", {"locations": "fastapi/routing.py:APIRouter"}))
        yield LlmResponse(content=types.Content(role="model", parts=[
            types.Part(function_call=types.FunctionCall(name=call[0], args=call[1]))]))


def test_bad_tool_args_do_not_lose_the_task(tmp_path):
    _, t, ws, cg, gold = load_task(tmp_path, 0)
    res = asyncio.run(localize(cg, t["issue"], "harness", ws, model=RaisingLlm(model="fake")))
    assert res["status"] == "ok" and res["pred"] == ["fastapi.routing.APIRouter"]
    assert score(res["pred"], gold)["sym_acc@1"] == 1.0


def test_stats_helpers():
    assert mcnemar_exact([1] * 10 + [0] * 5, [0] * 10 + [0] * 5)[2] < 0.01
    assert mcnemar_exact([1, 0], [0, 1])[2] == 1.0
    assert holm([0.01, 0.04]) == [0.02, 0.04]


def test_end_to_end_cli_and_report(tmp_path):
    d = make_real(tmp_path)
    out = tmp_path / "res"
    for cond in ("nollm",):
        subprocess.run([sys.executable, "-m", "src.run_localize", "--data", str(d), "--cond", cond,
                        "--out", str(out / f"{cond}.jsonl")], cwd=ROOT, check=True)
    rows = [json.loads(l) for l in open(out / "nollm.jsonl")]
    assert [r["gold"]["symbols"] for r in rows] == [["fastapi.routing.APIRouter"], ["settings.app01.main.get_settings"]]
    r = subprocess.run([sys.executable, "-m", "src.report", str(out / "nollm.jsonl")], cwd=ROOT,
                       capture_output=True, text=True, check=True)
    assert "2 scorable" in r.stdout


def test_run_command_allows_normal_searches(tmp_path):
    _, _, ws, cg, _ = load_task(tmp_path, 0)
    run = {f.__name__: f for f in cg.tools("base", ws)}["run_command"]
    for ok in ['grep -rn "/items/" .', "grep -rn 'path=\"/\"' .", "ls fastapi | head", "python3 -c 'print(1)'"]:
        assert "NotAllowed" not in run(ok), ok
    for bad in ["cat /tmp/x", "ls /usr/lib", "find / -name x", "cat /etc/passwd", "ls /home"]:
        assert "NotAllowed" in run(bad), bad


def test_guard_against_reviewer_bypasses(tmp_path):
    _, _, ws, cg, _ = load_task(tmp_path, 0)
    run = {f.__name__: f for f in cg.tools("base", ws)}["run_command"]
    for bad in ['ls ..', 'ls /*', 'ls /k*', 'cat $(echo L2V0Yy9ob3N0bmFtZQ==|base64 -d)',
                'python3 -c "print(open(chr(47)+\'etc/hostname\').read())"', 'cd; cd -; echo $OLDPWD',
                'ls "$(dirname "$PWD")"', 'cd /\tusr && ls', 'ls $PWD/../', 'ls -d $(realpath -m $PWD/x/../../)',
                'python3 -c "import os; print(os.path.abspath(\'.\'))"']:
        assert "NotAllowed" in run(bad), bad
    for ok in ['grep -rn "def f(...)" .', 'grep -rn "/users/{id}" .', 'grep -rn "\\"/options\\"" .',
               'find . -name "*.py"', 'cat fastapi/routing.py']:
        assert "NotAllowed" not in run(ok), ok


def test_gold_reviewer_cases():
    src = ("import os\n\n\ndef f(x):\n    y = x\n    return y\n\n\n@deco\ndef g():\n    return 1\n\n\n"
           "class C:\n    def foo(self):\n        return 1\n\n    def bar(self):\n        return 2\n")
    ids = {"m.f", "m.g", "m.C", "m.C.foo", "m.C.bar"}
    G = lambda p: sorted(gold_locations("--- a/m.py\n+++ b/m.py\n" + p, lambda _: src, ids)["symbols"])
    assert G("@@ -4,4 +4,5 @@\n def f(x):\n     y = x\n     return y\n+    print(y)\n \n") == ["m.f"]
    assert G("@@ -15,4 +15,5 @@\n     def foo(self):\n         return 1\n+        x = 2\n \n     def bar(self):\n") == ["m.C.foo"]
    assert G("@@ -18,2 +18,3 @@\n     def bar(self):\n         return 2\n+        # end\n") == ["m.C.bar"]
    assert G("@@ -9,2 +9,3 @@\n @deco\n+@other\n def g():\n") == ["m.g"]
    assert G("@@ -1,2 +1,3 @@\n+import sys\n import os\n \n") == ["m"]
    assert G("@@ -5,0 +6,1 @@\n+    z = 1\n") == ["m.f"]
    assert G("@@ -19,2 +19,3 @@\n         return 2\n\\ No newline at end of file\n+        pass\n") == ["m.C.bar"]
    assert G("@@ -16,3 +16,6 @@\n         return 1\n \n+    def new(self):\n+        return 3\n+\n     def bar(self):\n") == ["m.C"]
    assert G("@@ -6,3 +6,6 @@\n     return y\n \n+def h():\n+    pass\n+\n \n @deco\n") == ["m"]


def test_norm_free_text_answers():
    assert _norm("Cls.fn in pkg/mod.py") == "pkg.mod.Cls.fn"
    assert _norm("pkg/mod.py (Cls.fn)") == "pkg.mod.Cls.fn"
    assert _norm("pkg/mod.py#L12") == "pkg.mod"


class DownServerLlm(BaseLlm):
    async def generate_content_async(self, llm_request, stream=False):
        class APIConnectionError(Exception):
            pass
        raise APIConnectionError("connection refused")
        yield  # pragma: no cover


def test_server_errors_are_marked_for_retry_not_scored(tmp_path):
    _, t, ws, cg, _ = load_task(tmp_path, 0)
    res = asyncio.run(localize(cg, t["issue"], "base", ws, model=DownServerLlm(model="fake")))
    assert res["status"].startswith("INFRA") and res["pred"] == []


class LoopingLlm(BaseLlm):
    """Keeps calling the same tool forever (like 12B did), but submits when only submit_locations is offered."""
    async def generate_content_async(self, llm_request, stream=False):
        names = [t for t in (llm_request.tools_dict or {})]
        if names == ["submit_locations"]:
            call = ("submit_locations", {"locations": "fastapi/routing.py:APIRouter"})
        else:
            call = ("run_command", {"command": "ls fastapi"})
        yield LlmResponse(content=types.Content(role="model", parts=[
            types.Part(function_call=types.FunctionCall(name=call[0], args=call[1]))]))


def test_looping_model_still_gets_an_answer(tmp_path):
    _, t, ws, cg, gold = load_task(tmp_path, 0)
    res = asyncio.run(localize(cg, t["issue"], "base", ws, model=LoopingLlm(model="fake"), max_llm_calls=5))
    assert "LlmCallsLimit" in res["status"] and res["pred"] == ["fastapi.routing.APIRouter"]
    assert any(t.get("nudged") for t in res["trace"])


class SilentThenTextLlm(BaseLlm):
    """Loops on tools; returns NOTHING when offered only submit_locations (the 12B failure);
    writes the answer as plain text when offered no tools."""
    async def generate_content_async(self, llm_request, stream=False):
        names = list(llm_request.tools_dict or {})
        if names == ["submit_locations"]:
            yield LlmResponse(content=types.Content(role="model", parts=[types.Part(text="")]))
        elif not names:
            yield LlmResponse(content=types.Content(role="model", parts=[
                types.Part(text="fastapi/routing.py:APIRouter, fastapi.routing.helper")]))
        else:
            yield LlmResponse(content=types.Content(role="model", parts=[
                types.Part(function_call=types.FunctionCall(name="read_file", args={"filepath": "fastapi/routing.py"}))]))


def test_silent_model_falls_back_to_text_answer(tmp_path):
    _, t, ws, cg, gold = load_task(tmp_path, 0)
    res = asyncio.run(localize(cg, t["issue"], "hint", ws, model=SilentThenTextLlm(model="fake"), max_llm_calls=4))
    assert res["pred"] == ["fastapi.routing.APIRouter", "fastapi.routing.helper"], res["pred"]
    steps = [x["nudged"] for x in res["trace"] if "nudged" in x]
    assert steps == [1, 2]
    assert score(res["pred"], gold)["sym_acc@1"] == 1.0


def test_answer_model_disables_thinking():
    from src.agent import default_model
    m = default_model(answer_only=True)
    assert m._additional_args.get("extra_body") == {"chat_template_kwargs": {"enable_thinking": False}}
