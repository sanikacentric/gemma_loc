"""Map a reference patch onto graph symbols (dotted paths) in the pre-fix repository."""
import re

from .data import ast_symbols, enclosing, module_of

HUNK = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")
PROTECTED = re.compile(r"(^|/)(tests?|testing)/|(^|/)test_[^/]*\.py$|_test\.py$|(^|/)conftest\.py$")


def is_test(path):
    return bool(PROTECTED.search(path))


def touched_lines(patch):
    """{path: (is_new_file, spans)}. spans: set of (a, b, indent) old-line triples:
    a removed/modified line L gives (L, L, None); a pure insertion between old lines L and L+1 gives
    (L, L+1, indent of the first non-blank inserted line). Insertions that directly replace removed lines are
    already located by the removed lines."""
    out, path, old, prev, run = {}, None, 0, " ", None
    for line in patch.splitlines():
        if line.startswith("--- "):
            p = line[4:].strip()
            path = None if p == "/dev/null" else re.sub(r"^a/", "", p)
            new = path is None
        elif line.startswith("+++ "):
            if path is None:
                path = re.sub(r"^b/", "", line[4:].strip())
            out.setdefault(path, (new, set()))
        elif (m := HUNK.match(line)):
            old, prev, run = int(m.group(1)), " ", None
            if m.group(2) == "0":   # pure insertion hunk: '@@ -L,0' means "after old line L"
                old += 1
        elif path is None or path not in out or line.startswith("\\"):
            continue                # '\ No newline at end of file' and lines outside a file
        elif line.startswith("-"):
            out[path][1].add((old, old, None))
            old += 1
            prev, run = "-", None
        elif line.startswith("+"):
            if prev == " ":          # start of a pure insertion run
                run = [old - 1, old, None]
                prev = "+"
            if run is not None and run[2] is None and line[1:].strip():
                run[2] = len(line[1:]) - len(line[1:].lstrip())
                out[path][1].add(tuple(run))
            elif run is not None and run[2] is None:
                pass                 # only blank lines so far; recorded once a non-blank line appears
        elif line.startswith(" "):
            if run is not None and run[2] is None:
                out[path][1].add((run[0], run[1], None))   # insertion of blank lines only
            old += 1
            prev, run = " ", None
    return out


def _common(a, b):
    """Common dotted prefix of two qualnames (None = module level)."""
    if not a or not b:
        return None
    pa, pb = a.split("."), b.split(".")
    n = 0
    while n < min(len(pa), len(pb)) and pa[n] == pb[n]:
        n += 1
    return ".".join(pa[:n]) or None


def resolve(name, ids):
    """Match a dotted name to a graph id: exact; drop a leading src-style prefix; climb to the parent symbol."""
    if not name:
        return None
    parts = name.split(".")
    for right in range(len(parts), 0, -1):
        for left in range(0, min(3, right - 1) if right > 1 else 1):
            cand = ".".join(parts[left:right])
            if cand in ids:
                return cand
    return None


def resolve_module(mod, ids):
    """Match a module path to the graph's naming (the graph drops some top-level prefixes, e.g. docs_src)."""
    for left in range(0, min(3, mod.count(".") + 1)):
        cand = ".".join(mod.split(".")[left:])
        if cand in ids or any(i.startswith(cand + ".") for i in ids):
            return cand
    return mod


def gold_locations(patch, read_source, ids):
    """read_source(path) -> source string or None. ids: set of graph node ids.
    Returns modules (dotted), symbols (graph ids), new_files (paths added by the patch)."""
    mods, syms, new_files = set(), set(), set()
    for path, (is_new, spans) in touched_lines(patch).items():
        if not path.endswith(".py") or is_test(path):
            continue
        src = None if is_new else read_source(path)
        if src is None:
            new_files.add(path)
            continue
        mod = resolve_module(module_of(path), ids)
        mods.add(mod)
        table = ast_symbols(src)
        lines = src.splitlines()
        start_of = {q: st for q, st, _ in table}
        indent_of = lambda q: len(lines[start_of[q] - 1]) - len(lines[start_of[q] - 1].lstrip())
        for a, b, ind in spans:
            if a == b:
                q = enclosing(table, a)
            else:
                qa = enclosing(table, a)
                if qa and ind is not None and ind > indent_of(qa):
                    q = qa           # inserted code is indented inside the symbol that precedes it
                else:
                    q = _common(qa, enclosing(table, b))
            hit = resolve(f"{mod}.{q}", ids) if q else None
            syms.add(hit or mod)  # module-level change -> the module itself
    # a module-level edit (e.g. an import) next to symbol-level edits in the same module is not a separate location
    syms = {s for s in syms if not (s in mods and any(o.startswith(s + ".") for o in syms))}
    return {"modules": mods, "symbols": syms, "new_files": new_files}


def is_test_symbol(name):
    parts = name.split(".")
    return any(p in ("tests", "test", "testing") or p.startswith("test_") for p in parts)
