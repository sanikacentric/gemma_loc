"""Load the competition data: tasks.jsonl, graphs/<repo>_<commit>.json, embeddings/<repo>_<commit>.npz,
snapshots/<instance_id>.tgz. Symbols are dotted paths, e.g. fastapi.routing.APIRouter.add_api_route."""
import ast
import glob
import json
import os
import tarfile
from pathlib import Path

import networkx as nx
import numpy as np


# ---------- tasks ----------
def load_tasks(data_dir):
    tasks = []
    for line in open(Path(data_dir) / "tasks.jsonl"):
        if line.strip():
            r = json.loads(line)
            tasks.append({
                "id": r["instance_id"], "repo": r.get("repo", ""), "commit": r.get("base_commit", ""),
                "issue": r.get("problem_statement", ""), "hints": r.get("hints_text", "") or "",
                "patch": r.get("patch", ""), "test_patch": r.get("test_patch", ""),
            })
    return tasks


def find_file(data_dir, sub, task, ext):
    hits = glob.glob(f"{data_dir}/{sub}/*_{task['commit']}{ext}") if task["commit"] else []
    return hits[0] if hits else None


# ---------- graph + embeddings ----------
def load_graph(path):
    d = json.load(open(path))
    G = nx.MultiDiGraph()
    for n in d["nodes"]:
        G.add_node(str(n.get("id", n.get("name"))), text=n.get("text", "") or "")
    for e in d.get("links", d.get("edges", [])):
        G.add_edge(str(e["source"]), str(e["target"]),
                   type=str(e.get("type", e.get("rel", e.get("label", e.get("key", "edge"))))))
    return G


def load_embeddings(path):
    """Returns (ids, L2-normalised matrix). Accepts the common npz layouts."""
    if not path:
        return None, None
    z = np.load(path, allow_pickle=True)
    keys = list(z.files)
    strs = [k for k in keys if z[k].ndim == 1 and z[k].dtype.kind in "UOS"]
    mats = [k for k in keys if z[k].ndim == 2 and z[k].dtype.kind == "f"]
    if strs and mats:
        ids, mat = [str(x) for x in z[strs[0]]], z[mats[0]]
    elif len(keys) == 1 and z[keys[0]].dtype == object and z[keys[0]].ndim == 0:
        obj = z[keys[0]].item()
        ids, mat = [str(k) for k in obj], np.stack([np.asarray(v) for v in obj.values()])
    elif keys and all(z[k].ndim == 1 and z[k].dtype.kind == "f" for k in keys):
        ids, mat = keys, np.stack([z[k] for k in keys])
    else:
        raise ValueError(f"Unknown npz layout in {path}: {[(k, z[k].shape, z[k].dtype) for k in keys]}")
    mat = mat.astype(np.float32)
    mat /= np.linalg.norm(mat, axis=1, keepdims=True) + 1e-8
    return ids, mat


# ---------- snapshots ----------
def _rel(name):
    """Tar member name -> repo-relative path. Strips a literal './' prefix only (keeps dotfiles intact)."""
    while name.startswith("./"):
        name = name[2:]
    return "" if name == "." else name.lstrip("/")


def _strip_root(names):
    """Snapshots may wrap the repo in one top-level folder; return that prefix to strip ('' if none)."""
    rels = [r for r in map(_rel, names) if r]
    tops = {r.split("/")[0] for r in rels}
    if len(tops) == 1:
        top = tops.pop()
        if any(r.startswith(top + "/") for r in rels):
            return top + "/"
    return ""


def extract_snapshot(tgz, dest, only=None):
    """Extract the repo to dest. only = set of repo-relative paths -> extract just those (fast, for ground truth)."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    with tarfile.open(tgz, "r:*") as tf:
        members = tf.getmembers()
        prefix = _strip_root([m.name for m in members])
        for m in members:
            rel = _rel(m.name)
            if prefix and rel.startswith(prefix):
                rel = rel[len(prefix):]
            if not rel or ".." in rel.split("/"):
                continue
            if rel == ".git" or rel.startswith(".git/"):
                continue  # no git history for the agent (avoids any chance of seeing the fix)
            if only is not None and rel not in only:
                continue
            target = dest / rel
            if m.isdir():
                target.mkdir(parents=True, exist_ok=True)
            elif m.isfile():
                target.parent.mkdir(parents=True, exist_ok=True)
                with tf.extractfile(m) as src, open(target, "wb") as out:
                    out.write(src.read())
    return dest


# ---------- python source helpers ----------
def ast_symbols(source):
    """[(qualname, start, end)] for every def/class in a source string."""
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return []
    out = []

    def walk(node, prefix):
        for ch in ast.iter_child_nodes(node):
            if isinstance(ch, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                q = f"{prefix}.{ch.name}" if prefix else ch.name
                start = min([ch.lineno] + [d.lineno for d in ch.decorator_list])
                out.append((q, start, ch.end_lineno))
                walk(ch, q)

    walk(tree, "")
    return out


def enclosing(symbols, line):
    best = None
    for q, s, e in symbols:
        if s <= line <= e and (best is None or (e - s) < (best[2] - best[1])):
            best = (q, s, e)
    return best[0] if best else None


def module_of(path):
    p = path[:-3] if path.endswith(".py") else path
    if p.endswith("/__init__"):
        p = p[: -len("/__init__")]
    return p.replace("/", ".")
