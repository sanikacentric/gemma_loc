"""Run one localization condition over all tasks. Resumable: re-running skips finished tasks.

python -m src.run_localize --data /kaggle/input/competitions/gemma-4-developer-agent --cond nollm --out results/nollm.jsonl
conditions: nollm | base | emb | graph | harness | full
"""
import argparse
import json
import os
import shutil
import time
from pathlib import Path

from .data import extract_snapshot, find_file, load_embeddings, load_graph, load_tasks
from .ground_truth import gold_locations, resolve, resolve_module, touched_lines
from .graph_tools import CodeGraph, nollm_localize
from .metrics import graph_distance, score


def _to_graph(pred, ids):
    """Map an agent's answer onto the graph's naming: symbol id if possible, else the graph's module name
    (the graph drops some top-level prefixes such as fastapi's docs_src)."""
    return resolve(pred, ids) or resolve_module(pred, ids)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--cond", required=True, choices=["nollm", "base", "emb", "graph", "harness", "full", "hint"])
    ap.add_argument("--out", required=True)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--repo", default="", help="only tasks whose repo contains this string")
    ap.add_argument("--tmp", default="", help="scratch dir (default: unique per process, safe for parallel runs)")
    ap.add_argument("--max-llm-calls", type=int, default=15)
    a = ap.parse_args()
    a.tmp = a.tmp or f"/tmp/gemma_loc_ws_{a.cond}_{os.getpid()}"

    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    done = {json.loads(l)["id"] for l in open(out)} if out.exists() else set()
    tasks = [t for t in load_tasks(a.data) if a.repo in t["repo"]]
    tasks = tasks[: a.limit] if a.limit else tasks
    model_name = os.environ.get("MODEL_LABEL", os.environ.get("MODEL", "?")) if a.cond != "nollm" else "none"

    for i, t in enumerate(tasks):
        if t["id"] in done:
            continue
        gpath, tgz = find_file(a.data, "graphs", t, ".json"), f"{a.data}/snapshots/{t['id']}.tgz"
        if not gpath or not os.path.exists(tgz):
            print(f"[skip] {t['id']}: graph={bool(gpath)} snapshot={os.path.exists(tgz)}")
            continue
        t0 = time.time()
        ws = Path(a.tmp) / t["id"]
        shutil.rmtree(ws, ignore_errors=True)
        only = None if a.cond != "nollm" else set(touched_lines(t["patch"]))
        extract_snapshot(tgz, ws, only=only)

        G = load_graph(gpath)
        cg = CodeGraph(G, *load_embeddings(find_file(a.data, "embeddings", t, ".npz")))
        read = lambda p: (ws / p).read_text(errors="ignore") if (ws / p).is_file() else None
        gold = gold_locations(t["patch"], read, cg.idset)

        if a.cond == "nollm":
            res = {"pred": nollm_localize(cg, t["issue"]), "status": "ok", "trace": [], "tokens": {}, "steps": 0}
        else:
            from .agent import localize_sync
            hints = nollm_localize(cg, t["issue"], k=10) if a.cond == "hint" else None
            for attempt in range(3):  # retry server/connection hiccups on a fresh copy of the repo
                if attempt:
                    time.sleep(30)
                    shutil.rmtree(ws, ignore_errors=True)
                    extract_snapshot(tgz, ws)
                res = localize_sync(cg, t["issue"], a.cond, ws, max_llm_calls=a.max_llm_calls, hints=hints)
                if not res["status"].startswith("INFRA"):
                    break
            res["hints"] = hints
            res["raw_pred"] = res["pred"]
            res["pred"] = list(dict.fromkeys(_to_graph(p, cg.idset) for p in res["pred"]))
        shutil.rmtree(ws, ignore_errors=True)
        if res["status"].startswith("INFRA"):
            print(f"[retry-later] {t['id']}: {res['status'][:120]}  (not saved; re-run the same command to retry)")
            continue

        row = {"id": t["id"], "repo": t["repo"], "cond": a.cond, "model": model_name,
               "gold": {k: sorted(v) for k, v in gold.items()},
               "gold_in_graph": sum(s in cg.idset for s in gold["symbols"]),
               "metrics": score(res["pred"], gold),
               "distance": graph_distance(cg, t["issue"], gold["symbols"]),
               "graph_nodes": G.number_of_nodes(), **res}
        with open(out, "a") as f:
            f.write(json.dumps(row) + "\n")
        m = row["metrics"]
        print(f"[{i+1}/{len(tasks)}] {t['id']} mod_hit@5={m['mod_hit@5']:.0f} sym_hit@5={m['sym_hit@5']:.0f} "
              f"gold={len(gold['symbols'])} new_files={len(gold['new_files'])} dist={row['distance']} "
              f"steps={res['steps']} {res['status']} {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
