"""Compare runs: metrics with 95% CIs, paired tests vs a reference run (exact McNemar + Holm correction,
paired-difference CI), accuracy by graph distance, per repo, and a strict-gold sensitivity check.

python -m src.report results/*.jsonl            (first file whose cond is 'base' or 'harness' is the reference)
"""
import json
import sys
from collections import defaultdict

from .graph_tools import LEAK_MARKERS
from .metrics import bootstrap, holm, mcnemar_exact, paired_diff_ci

KEYS = ["mod_acc@1", "mod_hit@5", "sym_acc@1", "sym_hit@5", "sym_recall@5"]
MAIN = "sym_hit@5"


def load(paths):
    runs = {}
    for p in paths:
        rows = [json.loads(l) for l in open(p)]
        if not rows:
            continue
        name = f"{rows[0]['cond']}/{rows[0].get('model', '?')}".replace("/none", "")
        if name in runs:
            raise SystemExit(f"Two result files are both '{name}' ({p}); rename or pass only one.")
        runs[name] = {r["id"]: r for r in rows}
    return runs


def gold_key(r):
    return (tuple(r["gold"]["symbols"]), tuple(r["gold"]["modules"]))


def bucket(d):
    if d is None:
        return "n/a"
    if d >= 99:
        return "unreachable"
    return "0" if d == 0 else "1" if d == 1 else "2" if d == 2 else "3-8"


def main(paths):
    runs = load(paths)
    names = list(runs)
    common = set.intersection(*(set(r) for r in runs.values()))
    ref_rows = runs[names[0]]
    same_gold = sorted(i for i in common if len({gold_key(runs[n][i]) for n in names}) == 1)
    if len(same_gold) < len(common):
        print(f"WARNING: gold differs across runs for {len(common) - len(same_gold)} tasks -> excluded")
    ids = [i for i in same_gold if ref_rows[i]["gold"]["symbols"]]
    strict = [i for i in ids if not set(ref_rows[i]["gold"]["symbols"]) & set(ref_rows[i]["gold"]["modules"])]
    print(f"{len(common)} tasks in all runs; {len(ids)} scorable "
          f"({len(same_gold) - len(ids)} only add new files); {len(strict)} with function/class-level gold only\n")

    w = max(len(c) for c in names) + 2
    print("run".ljust(w) + "".join(f"{k:>22}" for k in KEYS) + f"{'steps':>7}")
    for n in names:
        rows = runs[n]
        cells = []
        for k in KEYS:
            m, lo, hi = bootstrap([rows[i]["metrics"][k] for i in ids])
            cells.append(f"{m:.3f} [{lo:.2f},{hi:.2f}]".rjust(22))
        steps = sum(rows[i]["steps"] for i in ids) / max(len(ids), 1)
        print(n.ljust(w) + "".join(cells) + f"{steps:7.1f}")

    ref = next((n for n in names if n.split("/")[0] in ("base", "harness")), names[0])
    others = [n for n in names if n != ref]
    if others:
        print(f"\nPaired comparison vs {ref} on {MAIN} (exact McNemar, Holm-corrected across {len(others)} tests):")
        b = [ref_val for ref_val in (runs[ref][i]["metrics"][MAIN] for i in ids)]
        raw = []
        stats = []
        for n in others:
            a = [runs[n][i]["metrics"][MAIN] for i in ids]
            wa, wb, p = mcnemar_exact(a, b)
            d, lo, hi = paired_diff_ci(a, b)
            raw.append(p)
            stats.append((n, wa, wb, d, lo, hi, p))
        for (n, wa, wb, d, lo, hi, p), padj in zip(stats, holm(raw)):
            print(f"  {n.ljust(w)} diff={d:+.3f} [{lo:+.2f},{hi:+.2f}]  wins/losses={wa}/{wb}  "
                  f"p={p:.3f}  p_holm={padj:.3f}")

    print(f"\n{MAIN} on tasks with function/class-level gold only (n={len(strict)}, sensitivity check):")
    for n in names:
        m, lo, hi = bootstrap([runs[n][i]["metrics"][MAIN] for i in strict])
        print(f"  {n.ljust(w)} {m:.3f} [{lo:.2f},{hi:.2f}]")

    print(f"\n{MAIN} by graph distance (issue keyword seeds -> gold symbol):")
    for n in names:
        buckets = defaultdict(list)
        for i in ids:
            buckets[bucket(runs[n][i]["distance"])].append(runs[n][i]["metrics"][MAIN])
        order = ["0", "1", "2", "3-8", "unreachable", "n/a"]
        print(f"  {n.ljust(w)} " + "  ".join(f"d={b}: {sum(buckets[b])/len(buckets[b]):.2f} (n={len(buckets[b])})"
                                            for b in order if buckets[b]))

    print(f"\nby repo ({MAIN}):")
    for n in names:
        by = defaultdict(list)
        for i in ids:
            by[runs[n][i]["repo"]].append(runs[n][i]["metrics"][MAIN])
        print(f"  {n.ljust(w)} " + "  ".join(f"{r}: {sum(v)/len(v):.2f} (n={len(v)})" for r, v in sorted(by.items())))

    print("\nrun status counts / tool-use audit:")
    for n in names:
        st, calls, blocked, leaks = defaultdict(int), defaultdict(int), 0, []
        for i in common:
            r = runs[n][i]
            st[r["status"].split(":")[0]] += 1
            for t in r["trace"]:
                if "call" in t:
                    calls[t["call"]] += 1
                res = str(t.get("result", ""))
                if "NotAllowed" in res:
                    blocked += 1
                if any(m in res for m in LEAK_MARKERS):
                    leaks.append(i)
        print(f"  {n.ljust(w)} {dict(st)}  blocked_cmds={blocked}  LEAK_SUSPECTS={sorted(set(leaks))}  "
              f"calls={dict(calls)}")


if __name__ == "__main__":
    main(sys.argv[1:])
