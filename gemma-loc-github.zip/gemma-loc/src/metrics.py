"""Localization metrics with bootstrap CIs, and the graph-distance analysis for the paper."""
import math

import networkx as nx
import numpy as np


def _under(x, g):
    return x == g or x.startswith(g + ".")


def score(pred, gold, k=5):
    """pred: ranked dotted symbols. A prediction hits a gold symbol if it is that symbol or inside it."""
    p = pred[:k]
    mods, syms = gold["modules"], gold["symbols"]
    mod_hit = lambda x: any(_under(x, m) for m in mods)
    sym_hit = lambda x: any(_under(x, s) for s in syms)
    found = {s for s in syms if any(_under(x, s) for x in p)}
    return {
        "mod_acc@1": float(bool(p) and mod_hit(p[0])),
        f"mod_hit@{k}": float(any(mod_hit(x) for x in p)),
        "sym_acc@1": float(bool(p) and sym_hit(p[0])),
        f"sym_hit@{k}": float(any(sym_hit(x) for x in p)),
        f"sym_recall@{k}": len(found) / len(syms) if syms else 0.0,
    }


def bootstrap(values, n=2000, seed=0):
    v = np.asarray(values, dtype=float)
    if len(v) == 0:
        return float("nan"), float("nan"), float("nan")
    means = np.random.default_rng(seed).choice(v, (n, len(v)), replace=True).mean(1)
    return float(v.mean()), float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def mcnemar_exact(a, b):
    """Two-sided exact McNemar (sign test on discordant pairs) for paired binary outcomes.
    Returns (wins_a, wins_b, p)."""
    wa = int(sum(1 for x, y in zip(a, b) if x > y))
    wb = int(sum(1 for x, y in zip(a, b) if x < y))
    n = wa + wb
    if n == 0:
        return wa, wb, 1.0
    k = min(wa, wb)
    p = 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return wa, wb, min(1.0, p)


def holm(pvals):
    """Holm-Bonferroni adjusted p-values (same order as input)."""
    order = sorted(range(len(pvals)), key=lambda i: pvals[i])
    adj, running = [0.0] * len(pvals), 0.0
    for rank, i in enumerate(order):
        running = max(running, min(1.0, (len(pvals) - rank) * pvals[i]))
        adj[i] = running
    return adj


def paired_diff_ci(a, b, n=2000, seed=0):
    """Mean of (a - b) with a 95% paired-bootstrap CI."""
    d = np.asarray(a, float) - np.asarray(b, float)
    idx = np.random.default_rng(seed).integers(0, len(d), (n, len(d)))
    m = d[idx].mean(1)
    return float(d.mean()), float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


def paired_bootstrap(a, b, n=2000, seed=0):
    """One-sided p-value that mean(a) does not exceed mean(b)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    idx = np.random.default_rng(seed).integers(0, len(a), (n, len(a)))
    return float(((a[idx] - b[idx]).mean(1) <= 0).mean())


def graph_distance(cg, issue, gold_symbols, seeds=5):
    """Hops from the issue's lexical seed symbols to the nearest gold symbol (99 = not within 8 hops).
    Seeds are chosen exactly like the no-LLM baseline (test symbols excluded)."""
    from .ground_truth import is_test_symbol
    seed_nodes = [n for n in cg.bm25_nodes(issue, seeds * 4)[0] if not is_test_symbol(n)][:seeds]
    gold = [g for g in gold_symbols if g in cg.U]
    if not seed_nodes or not gold:
        return None
    best = 99
    for s in seed_nodes:
        lengths = nx.single_source_shortest_path_length(cg.U, s, cutoff=8)
        best = min([best] + [lengths[g] for g in gold if g in lengths])
    return best
