"""Code-navigation tools that mirror the official swegemma harness tools (same names, args and limits),
plus our addition: rank_related (personalized PageRank over the code graph)."""
import json
import re
import subprocess
from pathlib import Path

import functools
import math
import os
from collections import Counter

import networkx as nx
import numpy as np


class BM25Okapi:
    """Minimal BM25 (no pip install needed on offline Kaggle GPU sessions)."""

    def __init__(self, corpus, k1=1.5, b=0.75):
        self.k1, self.b = k1, b
        self.tf = [Counter(doc) for doc in corpus]
        self.len = np.array([len(doc) for doc in corpus], dtype=float)
        self.avg = self.len.mean() if len(corpus) else 1.0
        df = Counter(t for doc in self.tf for t in doc)
        n = len(corpus)
        self.idf = {t: math.log((n - f + 0.5) / (f + 0.5) + 1) for t, f in df.items()}

    def get_scores(self, query):
        scores = np.zeros(len(self.tf))
        norm = self.k1 * (1 - self.b + self.b * self.len / self.avg)
        for t in set(query):
            if t not in self.idf:
                continue
            f = np.array([d.get(t, 0) for d in self.tf], dtype=float)
            scores += self.idf[t] * f * (self.k1 + 1) / (f + norm)
        return scores


TOK = re.compile(r"[A-Za-z][a-z0-9]*|[0-9]+")
MAX_CHARS = 5000  # harness max_stdout_chars
MAX_LINES = 150   # harness max_file_lines


def tokenize(text):
    text = re.sub(r"([a-z])([A-Z])", r"\1 \2", text or "").replace("_", " ").replace(".", " ")
    return [t.lower() for t in TOK.findall(text) if len(t) > 1]


def _int(x, default):
    try:
        return int(x)
    except (TypeError, ValueError):
        return default


def _safe(fn):
    """Never let a tool exception abort the agent run: return an error JSON instead (like the official harness)."""
    @functools.wraps(fn)
    def wrapper(*a, **kw):
        try:
            return fn(*a, **kw)
        except Exception as e:  # noqa: BLE001
            return _j({"status": "error", "error_type": type(e).__name__, "error_message": str(e)[:300]})
    return wrapper


# commands may only touch the task workspace: no absolute paths outside it, no parent dirs, no home dir
_B = r"(?=/|$|[\s;&|)'\"`*?\[{])"   # boundary after a path component
_SYS = (r"(kaggle|tmp|home|root|usr|etc|opt|proc|var|mnt|sys|bin|sbin|lib\w*|run|srv|boot|media|snap)" + _B
        + r"|dev/(?!null)")
_BLOCK = re.compile(
    r"(^|[\s;&|(`=<>\"'])/(" + _SYS + r")"        # absolute paths into system folders
    r"|(^|[\s;&|(`=<>\"'])/(?=$|[\s;&|)*?\[{])"     # bare root: 'ls /', 'ls /*', 'find / ...'
    r"|(^|[\s;&|(`=<>])/\w*[*?\[]"                  # globs at the root: 'ls /k*'
    r"|(^|[\s/;&|(`=<>\"'])\.\." + _B +             # parent directory: '..', '../x', '$PWD/../'
    r"|~|\$\{?HOME|\$\{?PWD|OLDPWD|\bdirname\b|\brealpath\b|\breadlink\b|base64|chr\(|os\.sep|__file__"
    r"|os\.path\.(abspath|dirname)|\bcd\s*($|[;&|])|\bcd\s+-|\bpushd\b|\bpopd\b"
    r"|tasks\.jsonl|gemma-loc|gemma_loc")

# tool outputs that would only appear if task/answer files had been read (checked by the report's audit)
LEAK_MARKERS = ("instance_id", '"gold"', "problem_statement", "test_patch")


def _j(d):
    s = json.dumps(d)
    return s if len(s) <= MAX_CHARS else s[:MAX_CHARS] + '..."(truncated)"'


class CodeGraph:
    def __init__(self, G, emb_ids=None, emb=None):
        self.G = G
        self.U = nx.Graph(G.to_undirected())  # simple undirected view for PageRank / distances
        self.ids = list(G.nodes)
        self.idset = set(self.ids)
        self.bm25 = BM25Okapi([tokenize(i + " " + G.nodes[i].get("text", "")[:1500]) for i in self.ids] or [["x"]])
        self.emb, self.row = emb, {}
        if emb is not None:
            self.row = {i: r for r, i in enumerate(emb_ids) if i in self.idset}
            self.row_ids = {r: i for i, r in self.row.items()}

    # harness-style 4-tier name resolution
    def resolve(self, name):
        name = (name or "").strip()
        if not name:
            return None
        if name in self.idset:
            return name
        for sep in (".", ";", "/"):
            hits = [i for i in self.ids if i.endswith(sep + name)]
            if hits:
                return min(hits, key=len)
        low = name.lower()
        hits = [i for i in self.ids if i.lower() == low] or [i for i in self.ids if low in i.lower()]
        return min(hits, key=len) if hits else None

    # ---- primitives ----
    def bm25_nodes(self, query, k=10):
        sc = self.bm25.get_scores(tokenize(query))
        top = [i for i in np.argsort(-sc)[:k] if sc[i] > 0]
        return [self.ids[i] for i in top], [float(sc[i]) for i in top]

    def similar_nodes(self, node, k=10):
        if self.emb is None or node not in self.row:
            return [], []
        sims = self.emb @ self.emb[self.row[node]]
        out = [r for r in np.argsort(-sims) if r in self.row_ids and self.row_ids[r] != node][:k]
        return [self.row_ids[r] for r in out], [float(sims[r]) for r in out]

    def ppr_nodes(self, seeds, k=10):
        seeds = [s for s in seeds if s in self.U]
        if not seeds:
            return [], []
        pr = nx.pagerank(self.U, alpha=0.85, personalization={s: 1.0 for s in seeds}, max_iter=100)
        top = sorted(pr, key=pr.get, reverse=True)[:k]
        return top, [pr[n] for n in top]

    # ---- agent tools ----
    def tools(self, condition, workspace):
        cg, ws = self, Path(workspace)

        def run_command(command: str) -> str:
            """Execute a shell command with /bin/bash -c inside the repository root. Output capped at 5000 chars.
            Use relative paths; the repository root is the current directory."""
            command = str(command).replace("/workspace/", "./").replace("/workspace", ".").replace(str(ws), ".")
            if _BLOCK.search(command):
                return _j({"status": "error", "error_type": "NotAllowed",
                           "error_message": "only relative paths inside the repository are allowed"})
            try:
                env = {**os.environ, "HOME": str(ws), "PWD": str(ws)}
                env.pop("OLDPWD", None)
                r = subprocess.run(["bash", "-c", command], cwd=ws, capture_output=True, text=True, timeout=60,
                                   env=env)
                return _j({"status": "ok" if r.returncode == 0 else "error", "exit_code": r.returncode,
                           "stdout": r.stdout[:MAX_CHARS], "stderr": r.stderr[:1000]})
            except subprocess.TimeoutExpired:
                return _j({"status": "error", "error_type": "TimeoutExceeded"})

        def read_file(filepath: str, start_line: int = 1, end_line: int = 150) -> str:
            """Read a repository file, 1-indexed inclusive line range, max 150 lines per call."""
            rel = str(filepath).replace(str(ws) + "/", "").replace("/workspace/", "")
            while rel.startswith("./"):
                rel = rel[2:]
            p = ws / rel.lstrip("/")
            if ".." in str(filepath) or not p.is_file():
                return _j({"status": "error", "error_message": f"not found: {filepath}"})
            lines = p.read_text(errors="ignore").splitlines()
            s = max(_int(start_line, 1), 1)
            e = min(_int(end_line, s + MAX_LINES - 1), s + MAX_LINES - 1, len(lines))
            body = "\n".join(f"{i}: {lines[i-1]}" for i in range(s, e + 1))[:10000]
            return _j({"status": "ok", "filepath": filepath, "content": body, "start_line": s, "end_line": e,
                       "total_lines": len(lines)})

        def get_code_neighbors(node: str, edge_type: str = "", max_neighbors: int = 50) -> str:
            """Find callers/callees and other graph neighbours of a symbol (e.g. pkg.module.Class.method)."""
            n = cg.resolve(node)
            if n is None:
                return _j({"status": "error", "error_message": f"unknown node {node}"})
            out = []
            for a, b, d in list(cg.G.out_edges(n, data=True)) + list(cg.G.in_edges(n, data=True)):
                if edge_type and d.get("type", "").lower() != edge_type.lower():
                    continue
                other, direction = (b, "out") if a == n else (a, "in")
                out.append(f"{direction}:{d.get('type','edge')}:{other}")
            out = list(dict.fromkeys(out))[: _int(max_neighbors, 50) or 50]
            return _j({"status": "ok", "node": n, "neighbors": out, "count": len(out)})

        def search_similar_code(query: str, k: int = 10) -> str:
            """Find the k symbols most similar to a symbol name (embeddings), or keyword search for free text."""
            k = _int(k, 10) or 10
            n = cg.resolve(query) if " " not in str(query).strip() else None
            nodes, sc = cg.similar_nodes(n, k) if n else ([], [])
            if not nodes:
                nodes, sc = cg.bm25_nodes(str(query), k)
            per = max(200, MAX_CHARS // max(len(nodes), 1))
            res = [{"node_name": x, "similarity": round(s, 4), "code": cg.G.nodes[x].get("text", "")[:per]}
                   for x, s in zip(nodes, sc)]
            return _j({"status": "ok", "query": query, "results": res, "count": len(res)})

        def get_code_subgraph(nodes: str) -> str:
            """Induced call subgraph for a comma-separated list of symbols."""
            ns = [cg.resolve(x.strip(" []\"'")) for x in str(nodes).split(",")]
            ns = [x for x in ns if x]
            sub = cg.G.subgraph(ns)
            edges = [{"from": a, "to": b, "type": d.get("type", "edge")} for a, b, d in sub.edges(data=True)]
            return _j({"status": "ok", "nodes": ns, "edges": edges})

        def rank_related(nodes: str) -> str:
            """Given comma-separated symbols you suspect, rank the 10 most structurally central related symbols
            in the code graph (personalized PageRank). Use it to find where a fix most likely belongs."""
            seeds = [cg.resolve(x.strip(" []\"'")) for x in str(nodes).split(",")]
            from .ground_truth import is_test_symbol
            top, sc = cg.ppr_nodes([s for s in seeds if s], 40)
            keep = [(n, x) for n, x in zip(top, sc) if not is_test_symbol(n)][:10]
            top, sc = [n for n, _ in keep], [x for _, x in keep]
            return _j({"status": "ok", "ranked": [{"node": n, "score": round(s, 5)} for n, s in zip(top, sc)]})

        run_command, read_file, get_code_neighbors, search_similar_code, get_code_subgraph, rank_related = map(
            _safe, (run_command, read_file, get_code_neighbors, search_similar_code, get_code_subgraph, rank_related))
        base = [run_command, read_file]
        graph = [get_code_neighbors, get_code_subgraph]
        return {
            "base": base,                                          # no code-intelligence tools
            "emb": base + [search_similar_code],                   # + embeddings
            "graph": base + graph,                                 # + code graph
            "harness": base + [search_similar_code] + graph,       # = official default tool set
            "full": base + [search_similar_code] + graph + [rank_related],  # + our PageRank tool
            "hint": base + [search_similar_code] + graph,          # official tools + PageRank candidates in prompt
        }[condition]


def nollm_localize(cg, issue, k=10, seeds=5):
    """Zero-model baseline: BM25 over symbol names+code from the issue text -> personalized PageRank."""
    from .ground_truth import is_test_symbol
    seed_nodes = [n for n in cg.bm25_nodes(issue, seeds * 4)[0] if not is_test_symbol(n)][:seeds]
    ranked = [n for n in cg.ppr_nodes(seed_nodes, k * 6)[0] if not is_test_symbol(n)]
    return list(dict.fromkeys(seed_nodes[:2] + ranked))[:k]
