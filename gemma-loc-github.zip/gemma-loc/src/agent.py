"""ADK localization agent: given an issue, find where the fix belongs. Same tools/limits as the official harness."""
import asyncio
import os
import re
import time

from google.adk.agents import LlmAgent, RunConfig
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

INSTRUCTION = """You are a software engineer localizing an issue in a Python repository.
Your ONLY job is to find WHERE the code change should be made. Do not write a fix.

Use the tools to explore. Read code before deciding. When confident, call submit_locations with up to 5
symbols, most likely first, comma-separated, as dotted paths like pkg.module.Class.method or pkg.module.function.
Example: submit_locations(locations="fastapi.routing.APIRouter.add_api_route, fastapi.utils.get_value_or_default")
Never list test files. Keep reasoning short. Always finish by calling submit_locations."""

SYM = re.compile(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)+")


def default_model(answer_only=False):
    """Gemma 4 served by vLLM's OpenAI-compatible server (see README).
    answer_only=True: the final-answer model, with thinking switched off so the output budget goes to the answer."""
    import litellm
    from google.adk.models.lite_llm import LiteLlm
    litellm.drop_params = True
    extra = {"extra_body": {"chat_template_kwargs": {"enable_thinking": False}}} if answer_only else {}
    return LiteLlm(model="openai/" + os.environ.get("MODEL", "gemma-4-31b-it-qat-w4a16-ct"),
                   api_base=os.environ.get("OPENAI_API_BASE", "http://localhost:8000/v1"),
                   api_key=os.environ.get("OPENAI_API_KEY", "EMPTY"), temperature=0.0,
                   max_tokens=1024 if answer_only else 2048, **extra)


def _norm(loc):
    """Accept 'pkg.mod.Cls.fn', 'pkg/mod.py::Cls.fn', 'pkg/mod.py:Cls.fn', 'pkg/mod.py:42', 'pkg/mod.py'
    -> dotted path 'pkg.mod.Cls.fn'. Dotted names that merely contain 'py' (e.g. _pytest.python.f) are kept."""
    loc = re.sub(r"#L\d+(-L?\d+)?", "", loc.strip())
    if (m := re.fullmatch(r"`?([\w.]+)`?\s+in\s+`?(\S+\.py)`?", loc)):        # 'Cls.fn in pkg/mod.py'
        loc = f"{m.group(2)}:{m.group(1)}"
    elif (m := re.fullmatch(r"(\S+\.py)\s*\(\s*([\w.]+)\s*\)", loc)):        # 'pkg/mod.py (Cls.fn)'
        loc = f"{m.group(1)}:{m.group(2)}"
    loc = loc.strip("`'\"[]() ").replace("/workspace/", "")
    while loc.startswith("./"):
        loc = loc[2:]
    m = re.search(r"\.py(?=$|:|\s)", loc)
    if m:  # a file path, optionally followed by :symbol or :line
        path, rest = loc[: m.start()], loc[m.end():].lstrip(":.").strip()
        if re.fullmatch(r"[\d\-,: ]*(lines?)?[\d\-,: ]*", rest or ""):
            rest = ""  # line numbers, not a symbol
    else:
        path, rest = loc.replace("::", ".").replace(":", "."), ""
    path = path.replace("/", ".").strip(".")
    if path.endswith(".__init__"):
        path = path[: -len(".__init__")]
    return f"{path}.{rest}" if rest else path


INFRA = ("APIConnectionError", "ServiceUnavailable", "InternalServerError", "APITimeoutError", "Timeout",
         "RateLimitError", "ConnectionError")


async def localize(cg, issue, condition, workspace, model=None, max_llm_calls=15, hints=None):
    submitted = []

    def submit_locations(locations: str) -> str:
        """Submit your final answer: up to 5 comma-separated dotted symbols, most likely first."""
        submitted.extend(_norm(x) for x in locations.split(",") if x.strip())
        return "submitted"

    agent = LlmAgent(name="localizer", model=model or default_model(), instruction=INSTRUCTION,
                     tools=cg.tools(condition, workspace) + [submit_locations])
    sessions = InMemorySessionService()
    runner = Runner(agent=agent, app_name="loc", session_service=sessions)
    s = await sessions.create_session(app_name="loc", user_id="u")
    text = f"Issue:\n{issue[:12000]}"
    if hints:
        text += ("\n\nCandidate locations ranked by a code-graph analysis of this issue (helpful but may be wrong; "
                 "verify by reading the code):\n" + "\n".join(f"{i+1}. {h}" for i, h in enumerate(hints)))
    msg = types.Content(role="user", parts=[types.Part(text=text)])

    trace, final_text, status, tokens = [], "", "ok", {"in": 0, "out": 0}
    t0 = time.time()
    try:
        async for ev in runner.run_async(user_id="u", session_id=s.id, new_message=msg,
                                         run_config=RunConfig(max_llm_calls=max_llm_calls)):
            if ev.usage_metadata:
                tokens["in"] += ev.usage_metadata.prompt_token_count or 0
                tokens["out"] += ev.usage_metadata.candidates_token_count or 0
            for p in (ev.content.parts if ev.content else []) or []:
                if p.function_call:
                    trace.append({"call": p.function_call.name, "args": dict(p.function_call.args or {})})
                elif p.function_response:
                    trace.append({"result_of": p.function_response.name,
                                  "result": str(p.function_response.response)[:1500]})
                elif p.text:
                    final_text = p.text
                    trace.append({"text": p.text[:2000]})
            if submitted:
                break
    except Exception as e:  # budget exhausted, context overflow, server errors -> logged, not fatal
        status = f"{type(e).__name__}: {str(e)[:300]}"

    if not submitted and not any(k in status for k in INFRA):
        # Like the official harness: ask for a final answer instead of losing the task.
        # Step 1: an agent that shares the conversation but has ONLY submit_locations (cannot keep exploring).
        # Step 2 (if step 1 produced nothing): a no-tools agent asked to write the locations as plain text.
        answer_model = default_model(answer_only=True) if model is None else model
        attempts = [
            ([submit_locations], "Exploration budget is used up. Call submit_locations now with your best 1-5 "
                                 "guesses based on what you have seen."),
            ([], "Reply with ONLY your best 1-5 locations as dotted paths (pkg.module.Class.method), "
                 "comma-separated, most likely first. No other text."),
        ]
        for step, (tools, text) in enumerate(attempts, 1):
            if submitted:
                break
            try:
                answer_agent = LlmAgent(name="localizer", model=answer_model, instruction=INSTRUCTION, tools=tools)
                answer_runner = Runner(agent=answer_agent, app_name="loc", session_service=sessions)
                nudge = types.Content(role="user", parts=[types.Part(text=text)])
                got = ""
                async for ev in answer_runner.run_async(user_id="u", session_id=s.id, new_message=nudge,
                                                        run_config=RunConfig(max_llm_calls=2)):
                    for p in (ev.content.parts if ev.content else []) or []:
                        if p.function_call:
                            trace.append({"call": p.function_call.name, "args": dict(p.function_call.args or {})})
                        elif p.text and not getattr(p, "thought", False):
                            got += p.text
                    if submitted:
                        break
                trace.append({"nudged": step, "reply": got[:1000]})
                if got.strip():
                    final_text = got
                    if step == 2:
                        break
            except Exception as e:
                trace.append({"nudged": step, "error": f"{type(e).__name__}: {str(e)[:200]}"})

    preds = submitted or [_norm(x) for x in re.findall(r"[\w./]+\.py(?::[\w.]+)?|" + SYM.pattern, final_text)]
    if not submitted and status == "ok":
        status = "no_submit"
    if any(k in status for k in INFRA):
        status = "INFRA: " + status
    return {"pred": list(dict.fromkeys(preds))[:5], "status": status, "trace": trace, "tokens": tokens,
            "steps": sum(1 for t in trace if "call" in t), "seconds": round(time.time() - t0, 1)}


def localize_sync(*a, **kw):
    return asyncio.run(localize(*a, **kw))
